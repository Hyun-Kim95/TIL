package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//치세요
import config.AppCtx;

import spring.ChangePasswordService;
import spring.DuplicateMemberException;
import spring.MemberInfoPrinter;
import spring.MemberListPrinter;
import spring.MemberNotFoundException;
import spring.MemberRegisterService;
import spring.RegisterRequest;
import spring.VersionPrinter;
import spring.WrongIdPasswordException;


public class MainForSpring {
	
	//치세요
	private static ApplicationContext ctx = null;
	
	public static void main(String[] args)throws IOException
	{
		//치세요
		ctx = new AnnotationConfigApplicationContext(AppCtx.class);
		
		BufferedReader reader = 
				new BufferedReader(new InputStreamReader(System.in));
		//입력 객체생성
		while(true)
		{
			System.out.println("명령어를 입력하세요 : ");
			String command = reader.readLine();
			//command 명령어
			if(command.equalsIgnoreCase("exit"))
			{
				System.out.println("종료합니다.");
				break;
			}
			
			if(command.startsWith("new "))
			{
				processNewCommand(command.split(" "));
				continue;
			}
			else if(command.startsWith("change "))
			{
				processChangeCommand(command.split(" "));
				continue;
			}
			else if (command.equals("list")) 
			{
				processListCommand();
				continue;
			} else if (command.startsWith("info ")) 
			{
				processInfoCommand(command.split(" "));
				continue;
			} else if (command.equals("version")) 
			{
				processVersionCommand();
			}
			printHelp();
			
		}
	}
	
	//spring(패키지)관련 클래스들을 조합해놓은 객체를 생성
	
	
	
	
	// new a b c d  => arg[0]= new arg[1] =a arg[2] = b arg[3] = c arg[4] = d length = 5
	private static void processNewCommand(String[] arg)
	{
		if(arg.length != 5)
		{
			printHelp();
			return;
		}
		//치세요
		MemberRegisterService regSvc = 
				ctx.getBean("memberRegSvc", 
						MemberRegisterService.class);
		RegisterRequest korea = new RegisterRequest();
		korea.setEmail(arg[1]);
		korea.setName(arg[2]);
		korea.setPassword(arg[3]);
		korea.setConfirmPassword(arg[4]);
		
		if(!korea.isPasswordEqualToConfirmPassword())
		{
			System.out.println("암호와 확인이 일치하지 않습니다.");
			return;
		}
		try {
			regSvc.regist(korea);
			System.out.println("등록했습니다.\n");
		}catch(DuplicateMemberException e){
			System.out.println("이미 존재하는 이메일입니다.\n");
		}
	}
	
	//agr[] 입력을 change a b c
	private static void processChangeCommand(String[] arg)
	{
		if(arg.length != 4)
		{
			printHelp();
			return;
		}
		
		//치세요
		ChangePasswordService changePwdSvc =
				ctx.getBean("changePwdSvc", 
						ChangePasswordService.class);
		//assembler에서 ChangePasswordServise 추출해놓은
		try {
			changePwdSvc.changePassword(arg[1], arg[2], arg[3]);
			System.out.println("암호를 변경했습니다.\n");
		} catch (MemberNotFoundException e) {
			System.out.println("존재하지 않는 이메일입니다.\n");
		}catch(WrongIdPasswordException e)
		{
			System.out.println("이메일과 암호가 일치하지 않습니다.\n");
		}
	}
	//
	private static void processInfoCommand(String[] arg)
	{
		if (arg.length != 2) {
			printHelp();
			return;
		}
		MemberInfoPrinter infoPrinter = 
				ctx.getBean("infoPrinter", 
						MemberInfoPrinter.class);
		infoPrinter.printMemberInfo(arg[1]); 
	}
	
	private static void processListCommand() {
		MemberListPrinter listPrinter = 
				ctx.getBean("listPrinter", MemberListPrinter.class);
		listPrinter.printAll();
	}
	
	private static void processVersionCommand() {
		VersionPrinter versionPrinter = 
				ctx.getBean("versionPrinter", VersionPrinter.class);
		versionPrinter.print();
	}
	
	//
	private static void printHelp()
	{
		System.out.println();
		System.out.println("잘못된 명령입니다. 아래 명령어 사용법을 확인하세요.");
		System.out.println("명령어 사용법:");
		System.out.println("new 이메일 이름 암호 암호확인");
		System.out.println("change 이메일 현재비번 변경비번");
		System.out.println();
	}
	
	
}
