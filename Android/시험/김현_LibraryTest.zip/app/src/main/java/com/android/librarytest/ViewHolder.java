package com.android.librarytest;

import android.widget.TextView;

public class ViewHolder {
    public TextView title;
    public TextView author;
    public TextView publisher;
}
